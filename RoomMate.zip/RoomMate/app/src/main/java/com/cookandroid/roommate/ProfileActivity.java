package com.cookandroid.roommate;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;

public class ProfileActivity extends AppCompatActivity {

    private EditText etName, etStudentId, etDescription;
    private RadioGroup rgGender;
    private Button btnSubmit;
    private SharedPreferences preferences;
    private static final String PREF_NAME = "profiles";
    private static final String KEY_PROFILES = "profile_list";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        initializeViews();
        setupSubmitButton();
    }

    private void initializeViews() {
        etName = findViewById(R.id.etName);
        etStudentId = findViewById(R.id.etStudentId);
        etDescription = findViewById(R.id.etDescription);
        rgGender = findViewById(R.id.rgGender);
        btnSubmit = findViewById(R.id.btnSubmit);
    }

    private void setupSubmitButton() {
        btnSubmit.setOnClickListener(v -> {
            if (validateInput()) {
                saveProfile();
            }
        });
    }

    private boolean validateInput() {
        String name = etName.getText().toString().trim();
        String studentId = etStudentId.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (name.isEmpty()) {
            etName.setError("이름을 입력해주세요");
            return false;
        }
        if (studentId.isEmpty()) {
            etStudentId.setError("학번을 입력해주세요");
            return false;
        }
        if (description.isEmpty()) {
            etDescription.setError("자기소개를 입력해주세요");
            return false;
        }
        return true;
    }

    private void saveProfile() {
        String name = etName.getText().toString().trim();
        String studentId = etStudentId.getText().toString().trim();
        String gender = rgGender.getCheckedRadioButtonId() == R.id.rbMale ? "남성" : "여성";
        String description = etDescription.getText().toString().trim();

        Profile profile = new Profile(name, studentId, gender, description);

        // 기존 프로필 목록 불러오기
        List<Profile> profiles = loadProfiles();
        profiles.add(profile);

        // 프로필 목록 저장
        Gson gson = new Gson();
        String json = gson.toJson(profiles);
        preferences.edit().putString(KEY_PROFILES, json).apply();

        Toast.makeText(this, "프로필이 저장되었습니다.", Toast.LENGTH_SHORT).show();
        finish();
    }

    private List<Profile> loadProfiles() {
        String json = preferences.getString(KEY_PROFILES, null);
        if (json == null) {
            return new ArrayList<>();
        }
        Gson gson = new Gson();
        Profile[] profileArray = gson.fromJson(json, Profile[].class);
        List<Profile> profiles = new ArrayList<>();
        for (Profile profile : profileArray) {
            profiles.add(profile);
        }
        return profiles;
    }
}