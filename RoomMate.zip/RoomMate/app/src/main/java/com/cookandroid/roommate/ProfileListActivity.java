package com.cookandroid.roommate;

import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.List;

public class ProfileListActivity extends AppCompatActivity {

    private RecyclerView recyclerProfiles;
    private ProfileAdapter adapter;
    private List<Profile> profileList;
    private SharedPreferences preferences;
    private static final String PREF_NAME = "profiles";
    private static final String KEY_PROFILES = "profile_list";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_list);

        preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);

        recyclerProfiles = findViewById(R.id.recyclerProfiles);
        recyclerProfiles.setLayoutManager(new LinearLayoutManager(this));

        profileList = new ArrayList<>();
        adapter = new ProfileAdapter(profileList);
        recyclerProfiles.setAdapter(adapter);

        loadProfiles();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadProfiles(); // 화면이 다시 보일 때마다 프로필 목록 새로고침
    }

    private void loadProfiles() {
        String json = preferences.getString(KEY_PROFILES, null);
        if (json != null) {
            Gson gson = new Gson();
            Profile[] profileArray = gson.fromJson(json, Profile[].class);
            profileList.clear();
            for (Profile profile : profileArray) {
                profileList.add(profile);
            }
            adapter.notifyDataSetChanged();
        }
    }
}