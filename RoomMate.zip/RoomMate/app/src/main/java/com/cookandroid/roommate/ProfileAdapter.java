package com.cookandroid.roommate;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.Gson;

import java.util.List;

public class ProfileAdapter extends RecyclerView.Adapter<ProfileAdapter.ViewHolder> {
    private List<Profile> profileList;
    private Context context;
    private static final String CHANNEL_ID = "roommate_request";
    private static final String CHANNEL_NAME = "Roommate Requests";

    public ProfileAdapter(List<Profile> profileList) {
        this.profileList = profileList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_profile, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Profile profile = profileList.get(position);
        holder.tvName.setText("이름: " + profile.getName());
        holder.tvStudentId.setText("학번: " + profile.getStudentId());
        holder.tvGender.setText("성별: " + profile.getGender());
        holder.tvDescription.setText("자기소개: " + profile.getDescription());

        holder.btnRequest.setOnClickListener(v -> {
            showRequestDialog(profile);
        });
    }

    private void showRequestDialog(Profile receiverProfile) {
        // 다이얼로그용 EditText 생성
        final EditText input = new EditText(context);
        input.setHint("당신의 이름을 입력하세요");

        AlertDialog.Builder builder = new AlertDialog.Builder(context)
                .setTitle("룸메이트 요청")
                .setMessage(receiverProfile.getName() + "님에게 룸메이트를 요청합니다.\n당신의 이름을 입력해주세요.")
                .setView(input)
                .setPositiveButton("요청하기", (dialog, which) -> {
                    String requesterName = input.getText().toString().trim();
                    if (!requesterName.isEmpty()) {
                        // SharedPreferences에서 프로필 목록 가져오기
                        SharedPreferences preferences = context.getSharedPreferences("profiles", Context.MODE_PRIVATE);
                        String json = preferences.getString("profile_list", null);
                        if (json != null) {
                            Gson gson = new Gson();
                            Profile[] profiles = gson.fromJson(json, Profile[].class);
                            Profile requesterProfile = null;

                            // 입력한 이름과 일치하는 프로필 찾기
                            for (Profile profile : profiles) {
                                if (profile.getName().equals(requesterName)) {
                                    requesterProfile = profile;
                                    break;
                                }
                            }

                            if (requesterProfile != null) {
                                sendRoommateRequest(receiverProfile, requesterProfile);
                            } else {
                                Toast.makeText(context,
                                        "프로필을 먼저 등록해주세요.",
                                        Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(context,
                                    "프로필을 먼저 등록해주세요.",
                                    Toast.LENGTH_LONG).show();
                        }
                    } else {
                        Toast.makeText(context, "이름을 입력해주세요", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("취소", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void sendRoommateRequest(Profile receiverProfile, Profile requesterProfile) {
        createNotificationChannel();

        // 긴 메시지 생성
        String bigText = String.format(
                "%s님이 %s님에게 룸메이트 요청을 보냈습니다.\n\n" +
                        "요청자 정보\n" +
                        "이름: %s\n" +
                        "학번: %s\n" +
                        "성별: %s\n" +
                        "자기소개: %s",
                requesterProfile.getName(),
                receiverProfile.getName(),
                requesterProfile.getName(),
                requesterProfile.getStudentId(),
                requesterProfile.getGender(),
                requesterProfile.getDescription()
        );

        // 알림 생성
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("새로운 룸메이트 요청")
                .setContentText(requesterProfile.getName() + "님이 룸메이트가 되고 싶어합니다.")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .setBigContentTitle("룸메이트 요청")
                        .setSummaryText("요청자 정보")
                        .bigText(bigText))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setDefaults(NotificationCompat.DEFAULT_ALL);

        // 알림 표시
        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        int notificationId = (int) System.currentTimeMillis();
        notificationManager.notify(notificationId, builder.build());

        // 토스트 메시지 표시
        Toast.makeText(context,
                receiverProfile.getName() + "님에게 룸메이트 요청을 보냈습니다.",
                Toast.LENGTH_SHORT).show();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH);  // 중요도를 HIGH로 변경
            channel.setDescription("룸메이트 요청 알림");
            channel.enableLights(true);
            channel.enableVibration(true);

            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(channel);
        }
    }

    @Override
    public int getItemCount() {
        return profileList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvStudentId, tvGender, tvDescription;
        Button btnRequest;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvName);
            tvStudentId = itemView.findViewById(R.id.tvStudentId);
            tvGender = itemView.findViewById(R.id.tvGender);
            tvDescription = itemView.findViewById(R.id.tvDescription);
            btnRequest = itemView.findViewById(R.id.btnRequest);
        }
    }
}